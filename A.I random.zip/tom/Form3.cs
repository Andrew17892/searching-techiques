﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tom
{
    public partial class Form3 : Form
    {
        Form1 fm ;
      public static int h = 0;
        public Form3(Form1 fm1)
        {
            InitializeComponent();
            //fm1.Close();
            //Form1.L.Clear();
        }
        //public name(Form1 form);
        private M exmapled = new M();
        public List<M> Lk = new List<M>();
        List<M> Lp = Form1.L2;
        int i;
        //int n= int.Parse(Form2.n);
        int c = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            
            c++;
            if (c < 26)
            {
                M pnn = new M();
                pnn.r = textBox1.Text;
                pnn.h = textBox2.Text;
                pnn.go = int.Parse(textBox3.Text);
                pnn.p = int.Parse(textBox4.Text);
                pnn.chl = int.Parse(textBox5.Text);
                pnn.chr = int.Parse(textBox6.Text);
                Form1.L7.Add(pnn);
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                label8.Text = c.ToString();
                
                

            }
            else
            {
                MessageBox.Show("you can not enter more than 26 node");
            }
            // c++;

            // Form1.L2[0].c=5;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Form1.ok = 0;
            h = 1;
            //fm.Show();
            Form1 frm2 = new Form1();
            frm2.Show();
           // h = 0;
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
