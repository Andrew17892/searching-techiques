﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tom
{
    public partial class Form1 : Form
    {
        Timer tt = new Timer();
       
        M pnn = new M();
        public static List<M> L = new List<M>();
        public static List<M> L2 = new List<M>();
        List<M> L3 = new List<M>();
        List<M> L4 = new List<M>();
        List<M> L5 = new List<M>();
        List<M> L6 = new List<M>();
        public static List<M> L7 = new List<M>();
        public Form1()
        {
            this.WindowState = FormWindowState.Maximized;
            this.MouseClick += Form1_MouseClick;
            this.Paint += Form1_Paint; ;
            this.KeyDown += Form1_KeyDown;
            // this.KeyUp += Form1_KeyUp;
            this.Load += Form1_Load1;
            tt.Tick += Tt_Tick;
            tt.Start();
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if(ok==1)
            {

            }
        }

        int c = 0;
        int k;
        int k2;
        int y;
        int y2;
        int c6 = 0;
        
        int f5=0;
       int  c5=11;
        int f10 = 0;
        int a10;
        string path;
        int t = 0;
        int f =10;
        int no;
        string bb;
        string name;
        private void Tt_Tick(object sender, EventArgs e)
        {
           
        
            if (f == 1)   //If the key pressed = n
            {
                path = null;    //wa2f 3nd el 'a' <tom> the start of the tree
                t = 0;         // pathcost
                for (i = 0; i < L2.Count; i++)    //loop to traverse through the whole tree
                {
                    if (L2[i].go == 1)   //goal { True, False }
                    {
                        a = i;         // position when ypu find it
                        break;
                    }
                }
                while (L2[i].p != 99)     //.p=parent
                {
                    path += L2[i].l;
                    no = int.Parse(L2[i].r);
                    t = t + no;
                    i = L2[i].p;
                }
                //putting letter a in the string
                path += L2[0].l;
                bb = new string(path.Reverse().ToArray());
                f = 0;
                name = "path way (Breadth-first):";
            }
            Stack<M> s = new Stack<M>();
            M pnn = new M();
            if (f == 2)
            {
                s.Clear();
                path = null;
                t = 0;
                if (L2.Count > 0)
                {
                    s.Push(L2[0]);
                }
                i = 0;
                while(s.Count != 0)
                {
                    pnn = s.Pop();
                    if (pnn.chl != 99)
                    {
                        s.Push(L2[pnn.chl]);
                    }
                    if (pnn.chr != 99)
                    {
                        s.Push(L2[pnn.chr]);
                    }
                    if(pnn.go==1)
                    {
                        for (i = 0; i < L2.Count; i++)
                        {
                            if (L2[i].l == pnn.l)
                            {
                                a = i;
                                break;
                            }
                        }

                        break;
                    }
                    
                }
                
                while (L2[i].p != 99)
                {
                    path += L2[i].l;
                    no = int.Parse(L2[i].r);
                    t = t + no;
                    i = L2[i].p;
                }
                if (L2.Count > 0)
                {
                    path += L2[0].l;
                }
               
                bb = new string(path.Reverse().ToArray());
                f = 0;
                name = "path way (Depth-first):";
            }
            
            if(f==4)
            {
                t = 0;
                for (i = 0; i < L2.Count; i++)
                {
                    L2[i].t = Int32.Parse(L2[i].h);
                }
                s.Clear();
                path = null;
                t = 0;
                if (L2.Count > 0)
                {
                    s.Push(L2[0]);
                }
                i = 0;
                L5.Clear();
                L6.Clear();

                while (s.Count != 0)
                {
                    pnn = s.Pop();
                    for (i = 0; i < L5.Count; i++)
                    {
                        if (pnn.l == L5[i].l)
                        {
                            L5.Remove(L5[i]);
                            break;
                        }
                    }
                    if (pnn.chl != 99)
                    {
                        L5.Add(L2[pnn.chl]);
                    }
                    if (pnn.chr != 99)
                    {
                        L5.Add(L2[pnn.chr]);
                    }
                    if (pnn.go == 1)
                    {
                        break;
                    }
                    L6.Clear();
                    for (i = 0; i < L5.Count; i++)
                    {
                        L6.Add(L5[i]);
                    }
                    while (L6.Count != 0)
                    {
                        int max = -99;

                        for(i = 0; i < L6.Count; i++)
                        {
                            //int y = Int32.Parse(L5[i].t);
                            if (L6[i].t > max)
                            {
                                max = L6[i].t;
                                a = i;
                            }

                        }


                        for (i = 0; i < L2.Count; i++)
                        {
                            if (L6[a].l == L2[i].l)
                            {
                                break;
                            }
                        }

                        //link l5 with l2

                        L6[a].t = Int32.Parse(L6[a].h);
                        s.Push(L6[a]);
                        L6.Remove(L6[a]);
                    }
                }
                t = 0;
                for (i = 0; i < L2.Count; i++)
                {
                    if (pnn.l == L2[i].l)
                    {
                        break;
                    }
                }
                while (L2[i].p != 99)
                {
                    path += L2[i].l;
                    no = int.Parse(L2[i].r);
                    t = t + no;
                    i = L2[i].p;
                }
                if (L2.Count > 0)
                {
                    path += L2[0].l;
                }
                
                bb = new string(path.Reverse().ToArray());
                f = 0;
                name = "path way (gready):";
            }
            if (f == 3)
            {
                t = 0;
                for (i = 0; i < L2.Count; i++)
                {
                    L2[i].t = 0;
                }
                for (i = 0; i < L2.Count; i++)
                {
                    int j = i;
                    t = 0;
                    while (L2[j].p != 99)
                    {
                        
                        no = int.Parse(L2[j].r);
                        t = t + no;
                        j = L2[j].p;
                    }
                    L2[i].t = t;
                }
                s.Clear();
                path = null;
                t = 0;
                if (L2.Count > 0)
                {
                    s.Push(L2[0]);
                }
                i = 0;
                L5.Clear();
                L6.Clear();
                while (s.Count != 0)
                {
                    pnn = s.Pop();
                    for (i = 0; i < L5.Count; i++)
                    {
                        if (pnn.l == L5[i].l)
                        {
                            L5.Remove(L5[i]);
                            break;
                        }
                    }

                    if (pnn.chl != 99)
                    {
                        L5.Add(L2[pnn.chl]);
                    }
                    if (pnn.chr != 99)
                    {
                        L5.Add(L2[pnn.chr]);
                    }
                    if (pnn.go == 1)
                    {
                        break;
                    }
                    L6.Clear();
                    for (i = 0; i < L5.Count; i++)
                    {
                        L6.Add(L5[i]);
                    }
                    while (L6.Count != 0)
                    {
                        int max = -99;

                        for (i = 0; i < L6.Count; i++)
                        {
                            
                            if (L6[i].t > max)
                            {
                                max = L6[i].t;
                                a = i;
                            }

                        }
                        

                        
                        
                        s.Push(L6[a]);
                        L6.Remove(L6[a]);
                    }
                }
                t = 0;
                for (i = 0; i < L2.Count; i++)
                {
                    if (pnn.l == L2[i].l)
                    {
                        break;
                    }
                }
                while (L2[i].p != 99)
                {
                    path += L2[i].l;
                    no = int.Parse(L2[i].r);
                    t = t + no;
                    i = L2[i].p;
                }
                if (L2.Count > 0)
                {
                    path += L2[0].l;
                }
               
                bb = new string(path.Reverse().ToArray());
                f = 0;
                name = "path way (Uniform-Cost):";
            }
            if (f == 5)
            {
                t = 0;
                for (i = 0; i < L2.Count; i++)
                {
                    L2[i].t = 0;
                }
                for (i = 0; i < L2.Count; i++)
                {
                    a = i;
                    t = 0;
                    while (L2[a].p != 99)
                    {
                        // path += L2[i].l;
                        no = int.Parse(L2[a].r);
                        t = t + no;
                        a = L2[a].p;
                    }
                    L2[i].t = t+ int.Parse(L2[i].h);
                }
                s.Clear();
                path = null;
                t = 0;
                if (L2.Count > 0)
                {
                    s.Push(L2[0]);
                }
                i = 0;
                L5.Clear();
                L6.Clear();
                while (s.Count != 0)
                {
                    pnn = s.Pop();
                    for (i = 0; i < L5.Count; i++)
                    {
                        if (pnn.l == L5[i].l)
                        {
                            L5.Remove(L5[i]);
                            break;
                        }
                    }

                    if (pnn.chl != 99)
                    {
                        L5.Add(L2[pnn.chl]);
                    }
                    if (pnn.chr != 99)
                    {
                        L5.Add(L2[pnn.chr]);
                    }
                    if (pnn.go == 1)
                    {
                        break;
                    }
                    L6.Clear();
                    for (i = 0; i < L5.Count; i++)
                    {
                        L6.Add(L5[i]);
                    }
                    while (L6.Count != 0)
                    {
                        int max = -99;

                        for (i = 0; i < L6.Count; i++)
                        {
                            
                            if (L6[i].t > max)
                            {
                                max = L6[i].t;
                                a = i;
                            }

                        }


                      
                        
                        s.Push(L6[a]);
                        L6.Remove(L6[a]);
                    }
                }
                t = 0;
                for (i = 0; i < L2.Count; i++)
                {
                    if (pnn.l == L2[i].l)
                    {
                        break;
                    }
                }
                while (L2[i].p != 99)
                {
                    path += L2[i].l;
                    no = int.Parse(L2[i].r);
                    t = t + no;
                    i = L2[i].p;
                }
                if (L2.Count > 0)
                {
                    path += L2[0].l;
                }
               
                bb = new string(path.Reverse().ToArray());
                f = 0;
                name = "path way (A*):";
            }
            DrawDB(CreateGraphics());
        }
        int i=0;
        int j = 0;
        int a;
        int r;
        int r2;
        int r3;
        int r4;
        int r5;
        int k3;
        int lv = 0;
        Random rr = new Random();
      
        private void Form1_Load1(object sender, EventArgs e)
        {
            onMemory = new Bitmap(ClientSize.Width, ClientSize.Height);
            // Random rr = new Random();
            if (Form3.h == 0)
            {
                r = rr.Next(4, 13);
                //number of selected pairs
                k = 0;
                for (i = 0; i < r; i++)
                {

                    if (c == 1)
                    {
                        pnn = new M();
                        pnn.x = x1 - a1;
                        pnn.y = y1 + b1;
                        pnn.lv = lv;

                        L.Add(pnn);
                        //pnn = new m();
                        c++;
                    }
                    if (c == 2)
                    {

                        pnn = new M();
                        pnn.x = x1 + a1;
                        pnn.y = y1 + b1;
                        pnn.lv = lv;
                        L.Add(pnn);
                        
                        c++;
                        lv++;
                    }
                    if (c == 0 || c == 3)
                    {
                        if (i > 0)
                        {
                            x1 = L[k].x;
                            y1 = L[k].y;
                            c++;
                            a1 = a1 - 5;
                        }
                        else
                        {
                            pnn.x = x1;
                            pnn.y = y1;
                            pnn.lv = lv;
                            L.Add(pnn);
                            lv++;
                            pnn = new M();
                            a1 = 400;
                        }
                        if (i == 1)
                        {
                            a1 = 200;
                        }
                        if (i == 2)
                        {
                            a1 = 200;
                        }
                        if (i == 3)
                        {
                            a1 = 100;
                        }
                        if (c == 0)
                        {
                            x1 = L[k].x;
                            y1 = L[k].y;


                        }
                        else
                        {
                            k++;
                            x1 = L[k].x;
                            y1 = L[k].y;
                        }
                        c = 1;
                    }

                    
                }
            }
            else
            {
                x1 = 810;
                 y1 = 100;
                k = 0;
                a1 = 100;
                 b1 = 100;
                for (i = 0; i < L7.Count-1; i++)
                {

                    if (c == 1)
                    {
                       
                            L7[i].x = x1 - a1;
                            L7[i].y = y1 + b1;
                            L7[i].lv = lv;
                            L.Add(L7[i]);


                        i++;
                            c++;
                        
                      
                        
                    }
                    if (c == 2)
                    {

                        L7[i].x = x1 + a1;
                        L7[i].y = y1 + b1;
                        L7[i].lv = lv;
                        
                        L.Add(L7[i]);
                       // i++;
                        c++;
                        lv++;
                    }
                    if (c == 0 || c == 3)
                    {
                        if (i > 0)
                        {
                            x1 = L7[k].x;
                            y1 = L7[k].y;
                            c++;
                            a1 = a1 - 5;
                        }
                        else
                        {
                            L7[i].x = x1;
                            L7[i].y = y1;
                            L7[i].lv = lv;
                            L.Add(L7[i]);
                            lv++;
                           
                            a1 = 400;
                        }
                        if (i == 1)
                        {
                            a1 = 200;
                        }
                        if (i == 2)
                        {
                            a1 = 200;
                        }
                        if (i == 3)
                        {
                            a1 = 100;
                        }
                        if (c == 0)
                        {
                            x1 = L7[k].x;
                            y1 = L7[k].y;


                        }
                        else
                        {
                            k++;
                            x1 = L7[k].x;
                            y1 = L7[k].y;
                        }
                        c = 1;
                    }

                    
                }

            }
           
           
           
            pnn = new M();
            pnn.im = new Bitmap("tom.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3.Add(pnn);
            pnn = new M();
            pnn.im = new Bitmap("jerry.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L4.Add(pnn);
            r4 = rr.Next(0, L.Count);
            r5 = rr.Next(0, L.Count);
            L3[0].x = 765;
            L3[0].y = 45;
            DrawDB(CreateGraphics());
        }
        
        int f2 = 0;
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.D0)
            {
                f = 10;
            }
            if (e.KeyCode == Keys.D1)
            {
                 f = 1;
            }
            if (e.KeyCode == Keys.D2)
            {
                f = 2;
            }
            if (e.KeyCode == Keys.D3)
            {
                if (f == 3)
                {
                    f = 0;
                }
                else
                {
                    f = 3;
                }
            }
            if (e.KeyCode == Keys.D4)
            {
                if (f == 4)
                {
                    f = 0;
                }
                else
                {
                    f = 4;
                }
            }
            if (e.KeyCode == Keys.D5)
            {
                if (f == 5)
                {
                    f = 0;
                }
                else
                {
                    f = 5;
                }
            }
            if (e.KeyCode == Keys.Enter)
            {

                
                ok = 1;
                L.Clear();
                L2.Clear();

                 Form3 frm2 = new Form3(this);
               
                frm2.Show();
                this.Hide();
            }
            if (e.KeyCode == Keys.R)
            {
                L.Clear();
                L2.Clear();
                this.Hide();
                Form1 frm2 = new Form1();
                frm2.Show();
            }
        }
        int ok = 0;
        Form1 fm1;
        Pen Pen = new Pen(Color.Yellow, 10);
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            
            DrawDB(CreateGraphics());
            
        }
        int x1 = 810;
        int y1 = 100;
        int a1 = 100;
        int b1 = 100;
        Bitmap onMemory;
        int ff = 0;
        int d = 0;
        int d2 = 0;
        int cx = 0;
        string v4;
        int cf = 0;
        void DrawScene(Graphics g)
        {
          

            ff = 0;
            d = 0;
            d2 = 0;
            c = 0;
           cx = 0;
            float v = 0;
            float v2 = 0;
            string v3;
            string[] le = new string[] { "a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
            g.Clear(Color.White);
            if (L.Count > 0)
            {
                L[0].r = "0";
            }
            for (i = 1; i < L.Count; i++)
            { // put and draw real value
                int ck = 0;
                if (i >= 3)
                {
                    c++;
                }
                if (c % 2 != 0 && c != 0)
                {
                   
                    ff++;
                    
                }

                Point p1 = new Point(L[ff].x, L[ff].y);
                //point of parent
                Point p2 = new Point(L[i].x, L[i].y);
                //point of child
                L[i].p = ff;
                if(L[ff].c==0 && cf==0)
                {
                    L[ff].chr = i;
                    L[ff].c++;
                    if (Form3.h == 0)
                    {
                        r = rr.Next(1, 10);
                        v4 = r.ToString();
                        L[i].r = v4;
                    }
                    v = (float)((L[i].x + L[ff].x) / 2);
                    v2 = (float)((L[i].y + L[ff].y) / 2);
                    L[i].xr = v;
                    L[i].yr = v2;
                }
                if (L[ff].c != 0 && cf == 0)
                {
                    L[ff].chl = i;
                    if (Form3.h == 0)
                    {
                        r = rr.Next(1, 10);
                        v4 = r.ToString();
                        L[i].r = v4;
                    }
                    v = (float)((L[i].x + L[ff].x-30) / 2);
                    v2 = (float)(L[i].y + L[ff].y - 30) / 2;
                    L[i].xr = v;
                    L[i].yr = v2;

                    
                }
                g.DrawLine(Pen, p1, p2);
                g.DrawString(L[i].r, new Font("Arial", 20, FontStyle.Bold), new SolidBrush(Color.Blue), L[i].xr, L[i].yr);
                
               

                
                //draw tom
                g.DrawImage(L3[0].im, L3[0].x, L3[0].y);
                
                // put and draw heouristic value
                if (i==1)
                {// put and draw heouristic value
                    v = (float)L[0].x - 10;
                    v2 = (float)L[0].y - 40;
                    g.DrawString(le[0], new Font("Arial", 20, FontStyle.Bold), new SolidBrush(Color.Black), v, v2);
                    r = rr.Next(0, 10);
                    v3 = r.ToString();
                    v = (float)L[0].x - 30;
                    pnn = new M();

                    pnn.x = L[0].x - 10;
                    pnn.y = L[0].y - 40;
                    pnn.h = v3;
                    pnn.l = le[0];
                    pnn.go = 0;
                    pnn.p = L[0].p;
                    pnn.chl = L[0].chl;
                    pnn.chr = L[0].chr;
                   
                    if (cf == 0)
                    {
                        L2.Add(pnn);
                    }
                    g.DrawString(L2[cx].h, new Font("Arial", 20, FontStyle.Bold), new SolidBrush(Color.Green), v, v2);
                    cx++;
                }
                   v = (float)L[i].x - 10;
                   v2 = (float)L[i].y - 40;
                    g.DrawString(le[i], new Font("Arial", 20, FontStyle.Bold), new SolidBrush(Color.Black), v, v2);
                    r = rr.Next(1, 10);
                     v3 = r.ToString();
                    v = (float)L[i].x - 30;
                    pnn = new M();
                    
                    pnn.x = L[i].x - 10;
                    pnn.y = L[i].y - 40;
                    pnn.h = v3;
                    pnn.l = le[i];
                    pnn.go = 0;
                pnn.p = L[i].p;
                pnn.chl = L[i].chl;
                pnn.chr = L[i].chr;
                if (cf == 0)
                {
                    L2.Add(pnn);
                }
                    g.DrawString(L2[cx].h, new Font("Arial", 20, FontStyle.Bold), new SolidBrush(Color.Green), v, v2);
                    cx++;
                    
                
            }
            if (f6 == 0)
            {

                if (Form3.h == 0)
                {
                    r = rr.Next(2, 5);
                    //number of goals
                    for (i = 0; i < r; i++)
                    {
                        r3 = rr.Next(4, L2.Count);
                        //location of each goal
                        L2[r3].go = 1;
                        L2[r3].h = "0";
                        f6 = 1;
                    }
                }
            }
            for (i = 0; i < L2.Count; i++)
            {
                if (L2[i].go == 1)
                {
                    L2[i].h= "0";

                    g.DrawImage(L4[0].im, L2[i].x - 20, L2[i].y + 40);
                    
                }
            }
            for (i = 0; i < L.Count; i++)
            {
                //make list to do the techinkes
                L2[i].p = L[i].p;
                L2[i].r = L[i].r;
                L2[i].chl = L[i].chl;
                L2[i].chr = L[i].chr;
                L2[i].r = L[i].r;
                if(Form3.h==1)
                {
                    L2[i].go = L[i].go;

                }
                
            }
            if(f==0)
            {
                //draw path way and cost

                v = 280;
                v2 = 550;
                g.DrawString(name, new Font("Arial", 20, FontStyle.Bold), new SolidBrush(Color.Black), v, v2);
                v = 600;
                v2 = 600;
                g.DrawString(bb, new Font("Arial", 20, FontStyle.Bold), new SolidBrush(Color.Green), v, v2);
                v = 450;
                v2 = 650;
                g.DrawString("path cost:", new Font("Arial", 20, FontStyle.Bold), new SolidBrush(Color.Black), v, v2);
                v = 600;
                v2 = 700;
                g.DrawString(t.ToString(), new Font("Arial", 20, FontStyle.Bold), new SolidBrush(Color.Blue), v, v2);

            }
            
            cf++;

        }
        int f6=0;
        void DrawDB(Graphics g)
        {
            
                Graphics g2 = Graphics.FromImage(onMemory);
                DrawScene(g2);

                g.DrawImage(onMemory, 0, 0);
            
            
        }

       
    }
}
