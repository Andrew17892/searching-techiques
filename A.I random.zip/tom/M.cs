﻿using System.Drawing;

namespace tom
{
    public class M
    {
        public int x, y, go, lv, c = 0, chl = 99, chr = 99, p = 99, t = 0;
        public Bitmap im;
        Point p1;
        Graphics g;
        public string h, r, l;
        //int chl,chr,p;
       // m pl, pr, pup;
        public float xr, yr;

    }
}